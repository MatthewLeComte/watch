' Shared auth helper. Imported via <script> where needed.
' Single shared secret baked into the app at build time.

function AuthHeaders() as Object
  headers = {}
  headers["X-Roku-Secret"] = RokuSecret()
  return headers
end function

function RokuSecret() as String
  return "c7c024e7b48c49deb71628fbdaea04fabbda52b459a050c233603c7c8ded1a6e"
end function
